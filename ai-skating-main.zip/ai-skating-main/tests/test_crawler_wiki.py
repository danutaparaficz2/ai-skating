import asyncio
import pytest
from crawler.service import ShortTrackCrawlerService
from crawler.models import CrawlTask

class DummyClient:
    def __init__(self):
        self.calls = {"search": 0, "summary": 0, "revisions": 0, "category": 0}

    async def search(self, query: str, limit: int = 10, language: str = "en"):
        self.calls["search"] += 1
        return [
            {"title": "Short track speed skating", "snippet": "Snippet", "wordcount": 100},
            {"title": "Speed skating", "snippet": "Snippet2", "wordcount": 200},
        ][:limit]

    async def category_members(self, category: str, limit: int = 50):
        self.calls["category"] += 1
        return ["Short track speed skating", "ISU World Cup short track"]

    async def summary(self, title: str):
        self.calls["summary"] += 1
        return {
            "title": title,
            "pageid": 123,
            "extract": f"Extract for {title}",
            "description": f"Desc {title}",
            "content_urls": {"desktop": {"page": f"https://en.wikipedia.org/wiki/{title.replace(' ', '_')}"}},
            "lang": "en",
        }

    async def revisions(self, title: str, limit: int = 3):
        self.calls["revisions"] += 1
        return [
            {"revid": 1, "parentid": 0, "timestamp": "2024-01-01T00:00:00Z", "user": "Test", "comment": "Init"},
            {"revid": 2, "parentid": 1, "timestamp": "2024-02-01T00:00:00Z", "user": "Test2", "comment": "Update"},
        ][:limit]

@pytest.mark.asyncio
async def test_crawl_basic():
    client = DummyClient()
    service = ShortTrackCrawlerService(client)
    task = CrawlTask(query="Short track speed skating", limit=5)
    result = await service.crawl(task)

    assert result.query == task.query
    # summaries at least one
    assert len(result.summaries) > 0
    # revisions collected
    assert len(result.revisions) > 0
    # search results reflect mock
    assert any(r.title == "Short track speed skating" for r in result.search_results)
    # Check calls to ensure flow
    assert client.calls["search"] >= 1
    assert client.calls["summary"] > 0
    assert client.calls["revisions"] > 0

@pytest.mark.asyncio
async def test_limit_titles_respected():
    class ManyTitlesClient(DummyClient):
        async def search(self, query: str, limit: int = 10, language: str = "en"):
            self.calls["search"] += 1
            return [{"title": f"Title {i}"} for i in range(limit)]
        async def category_members(self, category: str, limit: int = 50):
            self.calls["category"] += 1
            return [f"CatTitle {i}" for i in range(limit)]

    client = ManyTitlesClient()
    service = ShortTrackCrawlerService(client)
    task = CrawlTask(query="Short track", limit=7)
    result = await service.crawl(task)
    # Limit an Summaries sollte eingehalten werden
    assert len(result.summaries) <= task.limit

