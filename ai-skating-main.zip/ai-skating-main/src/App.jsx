import React, { useMemo, useState, useEffect } from "react";
import {
  Home as HomeIcon,
  Users,
  Calendar,
  Trophy,
  Zap,
  ChevronDown,
} from "lucide-react";

// Skaters (only 5 images available)
import FanKexin from "./assets/Fan_Kexin_anime.png";
import KristenSantos from "./assets/Kristen_Santos_Griswold_anime.png";
import ParkJiwon from "./assets/Park_Ji-won_anime.png";
import ShaolinLiu from "./assets/Shaolin_Sándor_Liu_anime.png";
import XandraVelzeboer from "./assets/xandra_velzeboer_anime.png";
import BoutinAnime from "./assets/boutin_anime.png";
import BrunelleAnime from "./assets/brunelle_anime.png";
import DesmetAnime from "./assets/desmet_anime.png";
import KimGAnime from "./assets/kimG_anime.png";

/* =========================================================================
   Fantasy Speed Skating 500m — Mobile-first, dark neon theme
   - Per-event lineup (3 starters + 2 bench)
   - Points by event finish position (degressive)
   - Demo event added: "Back To Back Eagle Golds — 500m Women Final — Seoul 2024" (5 skaters)
   - Lucide icons, Tailwind required
   ========================================================================= */

// --------------------------
// Mock Data (your athletes.json + photo mapping)
// --------------------------
const MOCK_DATA = {
  athletes: [
    {
      id: "a1",
      name: "Kristen Santos-Griswold",
      country: "USA",
      worldRank: 1,
      priceM: 50,
      form: 91,
      totalPoints: 0,
      priceHistory: [50, 50, 49],
      photo: KristenSantos,
      privateInfo:
        "Originally from Fairfield, Connecticut, Kristen lives with her two dogs, Bear and Koda. After stepping back from the 2026 U.S. Championships to recover from a back injury, she’s focused on returning for the Montreal World Cup. Outside the rink, she’s pursuing a PhD in physical therapy.",
      sportiveInfo:
        "From Disney Channel ads to the top of the world rankings: after the heartbreak of finishing 4th at Beijing 2022, Kristen made history as the first American woman to medal in all three individual distances at a World Championship. Now 31, she dominates the short track circuit while aiming for Milano-Cortina 2026.",
    },
    {
      id: "a2",
      name: "Xandra Velzeboer",
      country: "NED",
      worldRank: 2,
      priceM: 48,
      form: 89,
      totalPoints: 0,
      priceHistory: [48, 48, 47],
      photo: XandraVelzeboer,
    },
    {
      id: "a3",
      name: "Steven Dubois",
      country: "CAN",
      worldRank: 3,
      priceM: 47,
      form: 88,
      totalPoints: 0,
      priceHistory: [47, 47, 46],
    },
    {
      id: "a4",
      name: "William Dandjinou",
      country: "CAN",
      worldRank: 4,
      priceM: 45,
      form: 86,
      totalPoints: 0,
      priceHistory: [45, 45, 44],
    },
    {
      id: "a5",
      name: "Jens van ’t Wout",
      country: "NED",
      worldRank: 5,
      priceM: 43,
      form: 85,
      totalPoints: 0,
      priceHistory: [43, 43, 42],
    },
    {
      id: "a6",
      name: "Florence Brunelle",
      country: "CAN",
      worldRank: 6,
      priceM: 41,
      form: 83,
      totalPoints: 0,
      priceHistory: [41, 41, 40],
      photo: BrunelleAnime,
    },
    {
      id: "a7",
      name: "Hanne Desmet",
      country: "BEL",
      worldRank: 7,
      priceM: 39,
      form: 82,
      totalPoints: 0,
      priceHistory: [39, 39, 38],
      photo: DesmetAnime,
    },
    {
      id: "a8",
      name: "Choi Min-jeong",
      country: "KOR",
      worldRank: 8,
      priceM: 37,
      form: 81,
      totalPoints: 0,
      priceHistory: [37, 37, 36],
    },
    {
      id: "a9",
      name: "Park Ji-won",
      country: "KOR",
      worldRank: 9,
      priceM: 35,
      form: 79,
      totalPoints: 0,
      priceHistory: [35, 35, 34],
      photo: ParkJiwon,
    },
    {
      id: "a10",
      name: "Michelle Velzeboer",
      country: "NED",
      worldRank: 10,
      priceM: 34,
      form: 78,
      totalPoints: 0,
      priceHistory: [34, 34, 33],
    },
    {
      id: "a11",
      name: "Shaolin Sándor Liu",
      country: "CHN",
      worldRank: 11,
      priceM: 32,
      form: 77,
      totalPoints: 0,
      priceHistory: [32, 32, 31],
      photo: ShaolinLiu,
    },
    {
      id: "a12",
      name: "Suzanne Schulting",
      country: "NED",
      worldRank: 12,
      priceM: 31,
      form: 76,
      totalPoints: 0,
      priceHistory: [31, 31, 30],
    },
    {
      id: "a13",
      name: "Stijn Desmet",
      country: "BEL",
      worldRank: 13,
      priceM: 29,
      form: 74,
      totalPoints: 0,
      priceHistory: [29, 29, 28],
    },
    {
      id: "a14",
      name: "Kim GILLI",
      country: "KOR",
      worldRank: 14,
      priceM: 27,
      form: 73,
      totalPoints: 0,
      priceHistory: [27, 27, 26],
      photo: KimGAnime,
    },

    {
      id: "a15",
      name: "Yara van Kerkhof",
      country: "NED",
      worldRank: 15,
      priceM: 25,
      form: 72,
      totalPoints: 0,
      priceHistory: [25, 25, 24],
    },
    {
      id: "a16",
      name: "Rikki Doak",
      country: "CAN",
      worldRank: 16,
      priceM: 23,
      form: 70,
      totalPoints: 0,
      priceHistory: [23, 23, 22],
    },
    {
      id: "a17",
      name: "Abzal Azhgaliyev",
      country: "KAZ",
      worldRank: 17,
      priceM: 21,
      form: 69,
      totalPoints: 0,
      priceHistory: [21, 21, 20],
    },
    {
      id: "a18",
      name: "Paal André Kjell",
      country: "NOR",
      worldRank: 18,
      priceM: 19,
      form: 67,
      totalPoints: 0,
      priceHistory: [19, 19, 18],
    },
    {
      id: "a19",
      name: "Fan Kexin",
      country: "CHN",
      worldRank: 19,
      priceM: 17,
      form: 65,
      totalPoints: 0,
      priceHistory: [17, 17, 16],
      photo: FanKexin,
    },
    {
      id: "a20",
      name: "Itzhak de Laat",
      country: "NED",
      worldRank: 20,
      priceM: 15,
      form: 63,
      totalPoints: 0,
      priceHistory: [15, 15, 14],
    },
    {
      id: "a21",
      name: "Kim Boutin",
      country: "CAN",
      worldRank: 22,
      priceM: 26,
      form: 84,
      totalPoints: 0,
      priceHistory: [26, 26, 25],
      photo: BoutinAnime,
    },
  ],

  events: [
    // Demo event with 5 finishers (for your showcase)
    {
      id: "e1",
      name: "Back To Back Eagle Golds — 500m Women Final — Seoul 2024",
      country: "KOR",
      date: "2024-12-XX",
      city: "Seoul",
      finishOrder: ["a6", "a1", "a7", "a14", "a21"], // 1st..5th (can be changed anytime)
    },

    // Your existing tour events (can still use finishOrder later)
    {
      id: "e2",
      name: "World Cup Montréal — 500m Final",
      country: "CAN",
      date: "2025-11-15",
      city: "Montréal",
      results: {},
    },

    {
      id: "e3",
      name: "World Cup Salt Lake City — 500m",
      country: "USA",
      date: "2025-12-06",
      city: "Salt Lake City",
      results: {},
    },

    {
      id: "e4",
      name: "World Cup Dresden — 500m",
      country: "GER",
      date: "2026-01-10",
      city: "Dresden",
      results: {},
    },

    {
      id: "e5",
      name: "World Cup Dordrecht — 500m",
      country: "NED",
      date: "2026-01-24",
      city: "Dordrecht",
      results: {},
    },

    {
      id: "e6",
      name: "Tokyo Finals — 500m Grand Final",
      country: "JPN",
      date: "2026-03-07",
      city: "Tokyo",
      results: {},
    },
  ],

  leaderboards: {
    global: [
      { user: "SkateBrain", points: 312 },
      { user: "IceMasters", points: 296 },
      { user: "BladeStorm", points: 284 },
    ],
    countries: [
      { country: "NED", user: "LowlandsEdge", points: 210 },
      { country: "KOR", user: "HanRockets", points: 205 },
      { country: "CAN", user: "MapleGlide", points: 201 },
    ],
    privateLeague: {
      name: "Friends League",
      code: "JOIN-8X3K",
      table: [
        { user: "You", points: 0 },
        { user: "Ava", points: 202 },
        { user: "Noah", points: 187 },
      ],
    },
  },
};

// --------------------------
// Helpers + Storage
// --------------------------
const LS_KEY = "fantasy-speed-skating-team-v2";
const STARTER_SLOTS = 3;
const BENCH_SLOTS = 2;
const POINTS_LADDER = [25, 20, 15, 10, 5, 1];

function useLocalStorageState(key, initialValue) {
  const [state, setState] = useState(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : initialValue;
    } catch {
      return initialValue;
    }
  });
  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(state));
  }, [key, state]);
  return [state, setState];
}
function classNames(...xs) {
  return xs.filter(Boolean).join(" ");
}
function initials(name) {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}
function currencyM(m) {
  return `€${m.toFixed(1)}M`;
}

function getEventPointsForAthlete(event, athleteId) {
  if (!event.finishOrder) return event.results?.[athleteId] || 0;
  const pos = event.finishOrder.indexOf(athleteId);
  if (pos === -1) return 0;
  return POINTS_LADDER[pos] || 0;
}

function computeSeasonPoints(lineupsByEvent) {
  return MOCK_DATA.events.reduce((sum, ev) => {
    const lu = lineupsByEvent[ev.id] || { starters: [], bench: [] };
    const startersPts = lu.starters.reduce(
      (acc, id) => acc + getEventPointsForAthlete(ev, id),
      0
    );
    return sum + startersPts; // bench scores 0 for demo
  }, 0);
}

// --------------------------
// Small UI bits
// --------------------------
function SlotCircle({ filled, label, onClick, photo }) {
  return (
    <button
      onClick={onClick}
      className={classNames(
        "w-16 h-16 rounded-full overflow-hidden flex items-center justify-center text-xs font-semibold border transition transform active:scale-[0.98]",
        filled
          ? "border-cyan-400 shadow-[0_0_0_2px_rgba(34,211,238,0.35)]"
          : "border-white/20 text-slate-300 bg-white/5"
      )}
    >
      {photo ? (
        <img src={photo} alt={label} className="object-cover w-full h-full" />
      ) : (
        <span className="text-slate-100">{label}</span>
      )}
    </button>
  );
}
function Tag({ children }) {
  return (
    <span className="px-2 py-0.5 rounded-full bg-white/10 text-slate-100 text-[11px] border border-white/15">
      {children}
    </span>
  );
}
function Stat({ label, value }) {
  return (
    <div className="flex flex-col">
      <span className="text-[11px] text-slate-300">{label}</span>
      <span className="text-base font-semibold text-white">{value}</span>
    </div>
  );
}
function Card({ children, className = "" }) {
  return (
    <section
      className={classNames(
        "p-4 rounded-2xl border border-white/10 bg-white/5 backdrop-blur",
        className
      )}
    >
      {children}
    </section>
  );
}

// --------------------------
// Header
// --------------------------
function Header({ route, myPoints }) {
  const titleMap = {
    home: "HOME",
    team: "MY TEAM",
    events: "EVENTS",
    leaderboards: "LEADERBOARDS",
  };
  return (
    <header className="fixed top-0 left-0 right-0 z-50">
      <div className="bg-gradient-to-r from-[#0a1a2f] to-[#000814] border-b border-white/10 shadow-lg">
        <div className="max-w-md mx-auto px-5 pt-5 pb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap size={22} className="text-sky-400" />
            <h1 className="font-bold text-white text-xl tracking-wide">
              {titleMap[route.id]}
            </h1>
          </div>
          <div className="hidden xs:block text-right">
            <div className="text-[11px] uppercase text-slate-300">
              Season Pts
            </div>
            <div className="text-white font-semibold">{myPoints}</div>
          </div>
        </div>
      </div>
    </header>
  );
}

// --------------------------
// Home
// --------------------------
function Home({ myPoints }) {
  const upcoming = MOCK_DATA.events[0];
  return (
    <div className="max-w-md mx-auto p-3 space-y-3">
      <Card>
        <h2 className="text-lg font-semibold text-white mb-1">Season</h2>
        <p className="text-xs text-slate-300">
          ISU Short Track World Tour — 500m Fantasy. Starters score by finish
          position.
        </p>
        <div className="mt-4 grid grid-cols-3 gap-3">
          <Stat label="Events" value={MOCK_DATA.events.length} />
          <Stat label="Budget" value="€200M" />
          <Stat label="Your Points" value={`${myPoints}`} />
        </div>
      </Card>

      <Card>
        <div className="flex items-center justify-between mb-2">
          <div className="text-white font-semibold">{upcoming.name}</div>
          <Tag>Next Event</Tag>
        </div>
        <div className="text-xs text-slate-300">
          {upcoming.city}, {upcoming.country} — {upcoming.date}
        </div>
      </Card>

      <Card>
        <h3 className="text-white font-semibold mb-2 text-sm">
          Scoring (per event)
        </h3>
        <div className="flex flex-wrap gap-2 text-xs">
          {POINTS_LADDER.map((p, i) => (
            <div
              key={p}
              className="px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-slate-200"
            >
              {i + 1}st: {p}
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// --------------------------
// Team (builder + per-event lineup)
// --------------------------
function Team({ openProfile, lineupsByEvent, setLineupsByEvent }) {
  const [team, setTeam] = useLocalStorageState(LS_KEY, {
    name: "You",
    budgetM: 200,
    squad: [],
    lineupsByEvent: {},
  });

  // keep lineups in sync with parent (single source of truth)
  useEffect(() => {
    setLineupsByEvent(team.lineupsByEvent || {});
  }, []); // eslint-disable-line

  const athletes = MOCK_DATA.athletes;
  const events = MOCK_DATA.events;

  const [selectedEventId, setSelectedEventId] = useState(events[0].id);

  const spent = useMemo(() => {
    return team.squad.reduce((sum, id) => {
      const a = athletes.find((x) => x.id === id);
      return sum + (a?.priceM || 0);
    }, 0);
  }, [team.squad, athletes]);

  const remaining = (team.budgetM - spent).toFixed(1);

  const currentLineup = team.lineupsByEvent?.[selectedEventId] || {
    starters: [],
    bench: [],
  };

  function updateLineup(newLineup) {
    const nextLineups = {
      ...(team.lineupsByEvent || {}),
      [selectedEventId]: newLineup,
    };
    setTeam({ ...team, lineupsByEvent: nextLineups });
    setLineupsByEvent(nextLineups);
  }

  function addToSquad(id) {
    if (team.squad.includes(id)) return;
    const a = athletes.find((x) => x.id === id);
    if (!a) return;
    const newSpent = spent + a.priceM;
    if (newSpent > team.budgetM) return alert("Budget exceeded");
    if (team.squad.length >= 5) return alert("Squad limit reached (5)");
    setTeam({ ...team, squad: [...team.squad, id] });
  }

  function removeFromSquad(id) {
    const nextSquad = team.squad.filter((x) => x !== id);
    const nextLineups = { ...(team.lineupsByEvent || {}) };
    for (const evId of Object.keys(nextLineups)) {
      nextLineups[evId] = {
        starters: nextLineups[evId].starters.filter((x) => x !== id),
        bench: nextLineups[evId].bench.filter((x) => x !== id),
      };
    }
    setTeam({ ...team, squad: nextSquad, lineupsByEvent: nextLineups });
    setLineupsByEvent(nextLineups);
  }

  function addToStarters(id) {
    if (!team.squad.includes(id)) addToSquad(id);
    if (currentLineup.starters.includes(id) || currentLineup.bench.includes(id))
      return;
    if (currentLineup.starters.length >= STARTER_SLOTS)
      return alert("Starters full");
    updateLineup({
      ...currentLineup,
      starters: [...currentLineup.starters, id],
    });
  }

  function addToBench(id) {
    if (!team.squad.includes(id)) addToSquad(id);
    if (currentLineup.starters.includes(id) || currentLineup.bench.includes(id))
      return;
    if (currentLineup.bench.length >= BENCH_SLOTS) return alert("Bench full");
    updateLineup({ ...currentLineup, bench: [...currentLineup.bench, id] });
  }

  function removeFromLineup(id) {
    updateLineup({
      starters: currentLineup.starters.filter((x) => x !== id),
      bench: currentLineup.bench.filter((x) => x !== id),
    });
  }

  const seasonPoints = useMemo(
    () => computeSeasonPoints(team.lineupsByEvent || {}),
    [team.lineupsByEvent]
  );

  return (
    <div className="max-w-md mx-auto p-3 space-y-3">
      <Card className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-white font-semibold">Build Your Squad</h2>
          <div className="flex items-center gap-3">
            <Stat label="Spent" value={currencyM(spent)} />
            <Stat label="Left" value={currencyM(Number(remaining))} />
          </div>
        </div>

        {/* Event selector */}
        <div className="p-2 rounded-xl bg-white/5 border border-white/10 space-y-1">
          <div className="text-xs text-slate-300">Lineup for event</div>

          <div className="relative w-full">
            <select
              value={selectedEventId}
              onChange={(e) => setSelectedEventId(e.target.value)}
              className="
              appearance-none bg-transparent text-slate-100 text-sm
              pr-7 pl-2 py-1 rounded-lg border border-white/10 w-full
              whitespace-normal break-words leading-tight
            "
            >
              {events.map((ev) => (
                <option
                  key={ev.id}
                  value={ev.id}
                  className="bg-[#0b1320] whitespace-normal break-words"
                >
                  {ev.name}
                </option>
              ))}
            </select>

            <ChevronDown
              size={14}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"
            />
          </div>
        </div>

        {/* Starters */}
        <div>
          <div className="text-xs text-slate-300 mb-2">
            Starters — {STARTER_SLOTS} score points for this event
          </div>
          <div className="flex items-center gap-3">
            {Array.from({ length: STARTER_SLOTS }).map((_, i) => {
              const id = currentLineup.starters[i];
              const a = athletes.find((x) => x.id === id);
              return (
                <SlotCircle
                  key={i}
                  filled={Boolean(a)}
                  label={a ? initials(a.name) : "+"}
                  photo={a?.photo}
                  onClick={() => a && removeFromLineup(a.id)}
                />
              );
            })}
          </div>
        </div>

        {/* Bench */}
        <div>
          <div className="text-xs text-slate-300 mb-2">
            Bench — {BENCH_SLOTS} backups
          </div>
          <div className="flex items-center gap-3">
            {Array.from({ length: BENCH_SLOTS }).map((_, i) => {
              const id = currentLineup.bench[i];
              const a = athletes.find((x) => x.id === id);
              return (
                <SlotCircle
                  key={i}
                  filled={Boolean(a)}
                  label={a ? initials(a.name) : "+"}
                  photo={a?.photo}
                  onClick={() => a && removeFromLineup(a.id)}
                />
              );
            })}
          </div>
        </div>
      </Card>

      {/* Squad list */}
      <Card className="space-y-2">
        <div className="text-white font-semibold mb-1 text-sm">Your Squad</div>
        <div className="grid gap-2">
          {team.squad.map((id) => {
            const a = athletes.find((x) => x.id === id);
            if (!a) return null;

            const inStarters = currentLineup.starters.includes(id);
            const inBench = currentLineup.bench.includes(id);

            return (
              <div
                key={id}
                className="p-3 rounded-xl border border-white/10 bg-white/5 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full overflow-hidden border border-white/15 bg-white/10 flex items-center justify-center">
                    {a.photo ? (
                      <img
                        src={a.photo}
                        alt={a.name}
                        className="object-cover w-full h-full"
                      />
                    ) : (
                      <span className="text-slate-100 font-semibold text-sm">
                        {initials(a.name)}
                      </span>
                    )}
                  </div>
                  <div>
                    <div
                      className="text-slate-100 font-medium cursor-pointer hover:underline"
                      onClick={() => openProfile(a.id)}
                    >
                      {a.name}{" "}
                      <span className="text-slate-300">({a.country})</span>
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Rank #{a.worldRank} • Form {a.form}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Tag>{currencyM(a.priceM)}</Tag>

                  {!inStarters && !inBench && (
                    <>
                      <button
                        onClick={() => addToStarters(a.id)}
                        disabled={
                          currentLineup.starters.length >= STARTER_SLOTS
                        }
                        className="px-2 py-1 rounded-lg text-[12px] bg-cyan-500 text-black border border-cyan-400"
                      >
                        Starter
                      </button>

                      <button
                        onClick={() => addToBench(a.id)}
                        disabled={currentLineup.bench.length >= BENCH_SLOTS}
                        className="px-2 py-1 rounded-lg text-[12px] bg-white/10 text-slate-100 border border-white/15"
                      >
                        Bench
                      </button>
                    </>
                  )}

                  {(inStarters || inBench) && (
                    <button
                      onClick={() => removeFromLineup(a.id)}
                      className="px-2 py-1 rounded-lg text-[12px] bg-white/10 text-slate-100 border border-white/15"
                    >
                      Lineup
                    </button>
                  )}

                  <button
                    onClick={() => removeFromSquad(id)}
                    className="px-2 py-1 rounded-lg text-[12px] bg-white/10 text-slate-100 border border-white/15"
                  >
                    Remove
                  </button>
                </div>
              </div>
            );
          })}
          {team.squad.length === 0 && (
            <div className="text-xs text-slate-400">
              No skaters selected yet.
            </div>
          )}
        </div>
      </Card>

      {/* Transfer Market */}
      <Card className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="text-white font-semibold text-sm">
            Transfer Market
          </div>
          <Tag>{currencyM(Number(remaining))} left</Tag>
        </div>

        <div className="space-y-2 max-h-[52vh] overflow-auto pr-1">
          {athletes
            .slice()
            .sort((a, b) => a.worldRank - b.worldRank)
            .map((a) => {
              const inSquad = team.squad.includes(a.id);
              const canAfford = spent + a.priceM <= team.budgetM;

              return (
                <div
                  key={a.id}
                  className="p-3 rounded-xl border border-white/10 bg-white/5 flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full overflow-hidden border border-white/15 bg-white/10 flex items-center justify-center">
                      {a.photo ? (
                        <img
                          src={a.photo}
                          alt={a.name}
                          className="object-cover w-full h-full"
                        />
                      ) : (
                        <span className="text-slate-100 font-semibold text-sm">
                          {initials(a.name)}
                        </span>
                      )}
                    </div>
                    <div>
                      <div
                        className="text-slate-100 font-medium cursor-pointer hover:underline"
                        onClick={() => openProfile(a.id)}
                      >
                        {a.name}{" "}
                        <span className="text-slate-300">({a.country})</span>
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Rank #{a.worldRank} • Form {a.form}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Tag>{currencyM(a.priceM)}</Tag>

                    {!inSquad && (
                      <button
                        onClick={() => addToSquad(a.id)}
                        disabled={!canAfford || team.squad.length >= 5}
                        className={classNames(
                          "px-2 py-1 rounded-lg text-[12px] border",
                          canAfford && team.squad.length < 5
                            ? "bg-cyan-500 text-black border-cyan-400"
                            : "bg-white/10 text-slate-400 border-white/15 cursor-not-allowed"
                        )}
                      >
                        Add
                      </button>
                    )}

                    {inSquad && (
                      <button
                        onClick={() => removeFromSquad(a.id)}
                        className="px-2 py-1 rounded-lg text-[12px] bg-white/10 text-slate-100 border border-white/15"
                      >
                        Remove
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
        </div>

        <div className="mt-2 p-3 rounded-xl bg-white/5 border border-white/10 text-xs text-slate-200 flex items-center justify-between">
          <span>Projected season total (all event starters)</span>
          <span className="font-semibold text-white">{seasonPoints} pts</span>
        </div>
      </Card>
    </div>
  );
}

// --------------------------
// Events
// --------------------------
function Events({ lineupsByEvent, openProfile }) {
  const athletes = MOCK_DATA.athletes;

  return (
    <div className="max-w-md mx-auto p-3 space-y-3">
      {MOCK_DATA.events.map((ev) => {
        const lu = lineupsByEvent[ev.id] || { starters: [], bench: [] };

        const rows = ev.finishOrder
          ? ev.finishOrder.map((id, idx) => ({
              id,
              pos: idx + 1,
              pts: POINTS_LADDER[idx] || 0,
            }))
          : Object.entries(ev.results || {})
              .sort(([, pA], [, pB]) => pB - pA)
              .map(([id, pts], idx) => ({ id, pos: idx + 1, pts }));

        return (
          <Card key={ev.id}>
            <div className="flex items-center justify-between mb-2">
              <div className="text-white font-semibold">{ev.name}</div>
              <Tag>Event</Tag>
            </div>
            <div className="text-[11px] text-slate-300 mb-3">
              {ev.city}, {ev.country} — {ev.date}
            </div>

            {/* Your starters for this event */}
            <div className="mb-3">
              <div className="text-xs text-slate-300 mb-2">Your starters</div>
              <div className="flex items-center gap-2">
                {Array.from({ length: STARTER_SLOTS }).map((_, i) => {
                  const id = lu.starters[i];
                  const a = athletes.find((x) => x.id === id);
                  return (
                    <SlotCircle
                      key={i}
                      filled={Boolean(a)}
                      label={a ? initials(a.name) : ""}
                      photo={a?.photo}
                      onClick={() => a && openProfile(a.id)}
                    />
                  );
                })}
              </div>
            </div>

            {/* Results / finish order */}
            <div className="overflow-x-auto">
              <table className="w-full text-[12px] text-slate-200">
                <thead>
                  <tr className="text-left text-slate-300">
                    <th className="py-2">Pos</th>
                    <th>Skater</th>
                    <th>Country</th>
                    <th className="text-right">Pts</th>
                    <th className="text-right">Your gain</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => {
                    const a = athletes.find((x) => x.id === r.id);
                    const isYourStarter = lu.starters.includes(r.id);
                    return (
                      <tr key={r.id} className="border-t border-white/10">
                        <td className="py-2">{r.pos}</td>
                        <td className="font-medium">{a?.name || r.id}</td>
                        <td>{a?.country || ""}</td>
                        <td className="text-right font-semibold">{r.pts}</td>
                        <td className="text-right font-semibold">
                          {isYourStarter ? r.pts : 0}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Card>
        );
      })}
    </div>
  );
}

// --------------------------
// Leaderboards
// --------------------------
function Leaderboards({ myPoints }) {
  const [tab, setTab] = useState("global");
  const { global, countries, privateLeague } = MOCK_DATA.leaderboards;
  const myRow = { user: "You", points: myPoints };

  return (
    <div className="max-w-md mx-auto p-3 space-y-3">
      <div className="flex gap-2">
        {[
          { id: "global", label: "World" },
          { id: "countries", label: "Country" },
          { id: "private", label: "Private" },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={classNames(
              "px-3 py-1.5 rounded-full text-xs border transition",
              tab === t.id
                ? "bg-cyan-500 text-black border-cyan-400"
                : "bg-white/5 text-slate-100 border-white/10"
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "global" && (
        <Card>
          <div className="text-white font-semibold mb-2 text-sm">
            World Ranking
          </div>
          <Table
            rows={[myRow, ...global]}
            headers={["Rank", "User", "Points"]}
            rowMap={(r, i) => [i + 1, r.user, r.points]}
          />
        </Card>
      )}

      {tab === "countries" && (
        <Card>
          <div className="text-white font-semibold mb-2 text-sm">
            Country Ranking
          </div>
          <Table
            rows={countries}
            headers={["Rank", "User", "Country", "Points"]}
            rowMap={(r, i) => [i + 1, r.user, r.country, r.points]}
          />
        </Card>
      )}

      {tab === "private" && (
        <Card>
          <div className="flex items-center justify-between mb-2">
            <div className="text-white font-semibold text-sm">
              {privateLeague.name}
            </div>
            <Tag>Code: {privateLeague.code}</Tag>
          </div>
          <Table
            rows={[
              myRow,
              ...privateLeague.table.filter((x) => x.user !== "You"),
            ]}
            headers={["Rank", "User", "Points"]}
            rowMap={(r, i) => [i + 1, r.user, r.points]}
          />
        </Card>
      )}
    </div>
  );
}
function Table({ headers, rows, rowMap }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-[12px] text-slate-200">
        <thead>
          <tr className="text-left text-slate-300">
            {headers.map((h) => (
              <th key={h} className="py-2 pr-3">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, idx) => (
            <tr key={idx} className="border-t border-white/10">
              {rowMap(r, idx).map((cell, i) => (
                <td
                  key={i}
                  className={classNames(
                    "py-2 pr-3",
                    i === headers.length - 1 && "text-right font-semibold"
                  )}
                >
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// --------------------------
// Player Profile (modal)
// --------------------------
function PlayerSheet({ id, onClose }) {
  const a = MOCK_DATA.athletes.find((x) => x.id === id);
  if (!a) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex justify-center p-3"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md max-h-[90vh] overflow-y-auto my-auto rounded-2xl border border-white/10 bg-[#0b1320]/95 text-slate-100 p-9"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full overflow-hidden border border-white/15 bg-white/10 flex items-center justify-center">
              {a.photo ? (
                <img
                  src={a.photo}
                  alt={a.name}
                  className="object-cover w-full h-full"
                />
              ) : (
                <span className="text-slate-100 font-bold">
                  {initials(a.name)}
                </span>
              )}
            </div>
            <div>
              <div className="text-base font-semibold">
                {a.name} <span className="text-slate-300">({a.country})</span>
              </div>
              <div className="text-[11px] text-slate-400">
                World Rank #{a.worldRank} • Form {a.form}
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded-lg text-[12px] bg-white/10 border border-white/15"
          >
            Close
          </button>
        </div>

        <div className="grid grid-cols-3 gap-3 mb-5">
          <div className="p-3 rounded-xl bg-white/5 border border-white/10">
            <div className="text-[11px] text-slate-300">Price</div>
            <div className="font-semibold text-white">
              {currencyM(a.priceM)}
            </div>
          </div>
          <div className="p-3 rounded-xl bg-white/5 border border-white/10">
            <div className="text-[11px] text-slate-300">Season Points</div>
            <div className="font-semibold text-white">
              {MOCK_DATA.events.reduce(
                (sum, ev) => sum + getEventPointsForAthlete(ev, a.id),
                0
              )}{" "}
              pts
            </div>
          </div>
          <div className="p-3 rounded-xl bg-white/5 border border-white/10">
            <div className="text-[11px] text-slate-300">Price Trend</div>
            <div className="font-semibold text-white">
              {a.priceHistory.join(" → ")}
            </div>
          </div>
        </div>

        {(a.privateInfo || a.sportiveInfo) && (
          <div className="space-y-4 text-sm leading-relaxed">
            {a.sportiveInfo && (
              <div>
                <div className="text-[11px] uppercase text-sky-300 tracking-wide mb-1">
                  Sportive
                </div>
                <p className="text-slate-200 text-justify">{a.sportiveInfo}</p>
              </div>
            )}
            {a.privateInfo && (
              <div>
                <div className="text-[11px] uppercase text-sky-300 tracking-wide mb-1">
                  Private
                </div>
                <p className="text-slate-200 text-justify">{a.privateInfo}</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// --------------------------
// Bottom Navigation
// --------------------------
function BottomNav({ route, setRoute }) {
  const items = [
    { id: "home", label: "Home", icon: HomeIcon },
    { id: "team", label: "Team", icon: Users },
    { id: "events", label: "Events", icon: Calendar },
    { id: "leaderboards", label: "Leaders", icon: Trophy },
  ];
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-[#0b1c33]/90 backdrop-blur-md border-t border-white/10">
      <div className="max-w-md mx-auto grid grid-cols-4">
        {items.map((t) => {
          const Icon = t.icon;
          const active = route.id === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setRoute({ id: t.id })}
              className="py-3 text-xs flex flex-col items-center"
            >
              <Icon
                size={22}
                className={active ? "text-sky-400" : "text-gray-400"}
              />
              <span
                className={classNames(
                  "mt-1",
                  active ? "text-sky-300" : "text-gray-500"
                )}
              >
                {t.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}

// --------------------------
// App Shell
// --------------------------
export default function App() {
  const [route, setRoute] = useState({ id: "home" });
  const [profileId, setProfileId] = useState(null);

  const [lineupsByEvent, setLineupsByEvent] = useLocalStorageState(
    `${LS_KEY}-lineups`,
    {}
  );

  const myPoints = useMemo(
    () => computeSeasonPoints(lineupsByEvent || {}),
    [lineupsByEvent]
  );

  // Lock body scroll when modal open
  useEffect(() => {
    const prev = document.body.style.overflow;
    if (profileId) document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [profileId]);

  function openProfile(id) {
    setProfileId(id);
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#071427] via-[#0b1c33] to-black text-slate-100">
      {!profileId && <Header route={route} myPoints={myPoints} />}

      <main
        aria-hidden={Boolean(profileId)}
        className={classNames(
          "pb-20 transition-all duration-200",
          route.id === "team" ? "pt-[110px]" : "pt-[70px]"
        )}
      >
        {route.id === "home" && <Home myPoints={myPoints} />}
        {route.id === "team" && (
          <Team
            openProfile={openProfile}
            lineupsByEvent={lineupsByEvent}
            setLineupsByEvent={setLineupsByEvent}
          />
        )}
        {route.id === "events" && (
          <Events lineupsByEvent={lineupsByEvent} openProfile={openProfile} />
        )}
        {route.id === "leaderboards" && <Leaderboards myPoints={myPoints} />}
      </main>

      {profileId && (
        <PlayerSheet id={profileId} onClose={() => setProfileId(null)} />
      )}

      {!profileId && <BottomNav route={route} setRoute={setRoute} />}
    </div>
  );
}
