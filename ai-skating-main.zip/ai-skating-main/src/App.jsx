import React, { useMemo, useState, useEffect } from "react";
import { Home as HomeIcon, Users, Calendar, Trophy, Zap } from "lucide-react";

// Skaters
import FanKexin from "./assets/Fan_Kexin_anime.png";
import KristenSantos from "./assets/Kristen_Santos_Griswold_anime.png";
import ParkJiwon from "./assets/Park_Ji-won_anime.png";
import ShaolinLiu from "./assets/Shaolin_Sándor_Liu_anime.png";
import XandraVelzeboer from "./assets/xandra_velzeboer_anime.png";

/* =========================================================================
   Fantasy Speed Skating 500m — Mobile-first, dark neon theme
   - Full pages restored (Home / Team / Events / Leaderboards)
   - Bigger dynamic header (title changes per page)
   - Bottom navigation with Lucide icons
   - Tailwind required
   ========================================================================= */

// --------------------------
// Mock Data
// --------------------------
const MOCK_DATA = {
  athletes: [
    {
      id: "a1",
      name: "Kristen Santos-Griswold",
      country: "USA",
      worldRank: 1,
      priceM: 50,
      form: 91,
      totalPoints: 0,
      priceHistory: [50, 50, 49],
      photo: KristenSantos,
      privateInfo: "Originally from Fairfield, Connecticut, Kristen lives with her two dogs, Bear and Koda. After stepping back from the 2026 U.S. Championships to recover from a back injury, she’s focused on returning for the Montreal World Cup. Outside the rink, she’s pursuing a PhD in physical therapy.",
      sportiveInfo: "From Disney Channel ads to the top of the world rankings: after the heartbreak of finishing 4th at Beijing 2022, Kristen made history as the first American woman to medal in all three individual distances at a World Championship. Now 31, she dominates the short track circuit while aiming for Milano-Cortina 2026."
    },
    { id: "a2", name: "Xandra Velzeboer", country: "NED", worldRank: 2, priceM: 48, form: 89, totalPoints: 0, priceHistory: [48,48,47], photo: XandraVelzeboer },
    { id: "a3", name: "Steven Dubois", country: "CAN", worldRank: 3, priceM: 47, form: 88, totalPoints: 0, priceHistory: [47,47,46] },
    { id: "a4", name: "William Dandjinou", country: "CAN", worldRank: 4, priceM: 45, form: 86, totalPoints: 0, priceHistory: [45,45,44] },
    { id: "a5", name: "Jens van ’t Wout", country: "NED", worldRank: 5, priceM: 43, form: 85, totalPoints: 0, priceHistory: [43,43,42] },
    { id: "a6", name: "Florence Brunelle", country: "CAN", worldRank: 6, priceM: 41, form: 83, totalPoints: 0, priceHistory: [41,41,40] },
    { id: "a7", name: "Hanne Desmet", country: "BEL", worldRank: 7, priceM: 39, form: 82, totalPoints: 0, priceHistory: [39,39,38] },
    { id: "a8", name: "Choi Min-jeong", country: "KOR", worldRank: 8, priceM: 37, form: 81, totalPoints: 0, priceHistory: [37,37,36] },
    { id: "a9", name: "Park Ji-won", country: "KOR", worldRank: 9, priceM: 35, form: 79, totalPoints: 0, priceHistory: [35,35,34], photo: ParkJiwon },
    { id: "a10", name: "Michelle Velzeboer", country: "NED", worldRank: 10, priceM: 34, form: 78, totalPoints: 0, priceHistory: [34,34,33] },
    { id: "a11", name: "Shaolin Sándor Liu", country: "CHN", worldRank: 11, priceM: 32, form: 77, totalPoints: 0, priceHistory: [32,32,31], photo: ShaolinLiu },
    { id: "a12", name: "Suzanne Schulting", country: "NED", worldRank: 12, priceM: 31, form: 76, totalPoints: 0, priceHistory: [31,31,30] },
    { id: "a13", name: "Stijn Desmet", country: "BEL", worldRank: 13, priceM: 29, form: 74, totalPoints: 0, priceHistory: [29,29,28] },
    { id: "a14", name: "Kim Gilette", country: "FRA", worldRank: 14, priceM: 27, form: 73, totalPoints: 0, priceHistory: [27,27,26] },
    { id: "a15", name: "Yara van Kerkhof", country: "NED", worldRank: 15, priceM: 25, form: 72, totalPoints: 0, priceHistory: [25,25,24] },
    { id: "a16", name: "Rikki Doak", country: "CAN", worldRank: 16, priceM: 23, form: 70, totalPoints: 0, priceHistory: [23,23,22] },
    { id: "a17", name: "Abzal Azhgaliyev", country: "KAZ", worldRank: 17, priceM: 21, form: 69, totalPoints: 0, priceHistory: [21,21,20] },
    { id: "a18", name: "Paal André Kjell", country: "NOR", worldRank: 18, priceM: 19, form: 67, totalPoints: 0, priceHistory: [19,19,18] },
    { id: "a19", name: "Fan Kexin", country: "CHN", worldRank: 19, priceM: 17, form: 65, totalPoints: 0, priceHistory: [17,17,16], photo: FanKexin },
    { id: "a20", name: "Itzhak de Laat", country: "NED", worldRank: 20, priceM: 15, form: 63, totalPoints: 0, priceHistory: [15,15,14] },

  ],
  events: [
    { id: "e1", name: "Montreal World Cup", country: "CAN", date: "2025-11-15", city: "Montreal", results: { a1: 25, a2: 18, a3: 15, a4: 12, a5: 10, a6: 8, a7: 6, a8: 4, a9: 2 } },
    { id: "e2", name: "Salt Lake City World Cup", country: "USA", date: "2025-12-06", city: "Salt Lake City", results: { a2: 25, a1: 18, a4: 15, a3: 12, a5: 10, a6: 8, a7: 6, a10: 4, a11: 2 } },
    { id: "e3", name: "Dresden World Cup", country: "GER", date: "2026-01-10", city: "Dresden", results: { a3: 25, a4: 18, a1: 15, a2: 12, a5: 10, a8: 8, a7: 6, a9: 4, a12: 2 } },
    { id: "e4", name: "Dordrecht World Cup", country: "NED", date: "2026-01-24", city: "Dordrecht", results: { a1: 25, a6: 18, a3: 15, a4: 12, a2: 10, a5: 8, a8: 6, a7: 4, a9: 2 } },
    { id: "e5", name: "Seoul World Cup", country: "KOR", date: "2026-02-14", city: "Seoul", results: { a4: 25, a2: 18, a1: 15, a5: 12, a6: 10, a3: 8, a7: 6, a8: 4, a10: 2 } },
    { id: "e6", name: "Tokyo Finals", country: "JPN", date: "2026-03-07", city: "Tokyo", results: { a2: 25, a1: 18, a3: 15, a4: 12, a5: 10, a7: 8, a8: 6, a6: 4, a9: 2 } },
  ],
  leaderboards: {
    global: [
      { user: "SkateBrain", points: 312 },
      { user: "IceMasters", points: 296 },
      { user: "BladeStorm", points: 284 },
    ],
    countries: [
      { country: "NED", user: "LowlandsEdge", points: 210 },
      { country: "KOR", user: "HanRockets", points: 205 },
      { country: "CAN", user: "MapleGlide", points: 201 },
    ],
    privateLeague: {
      name: "Friends League",
      code: "JOIN-8X3K",
      table: [
        { user: "You", points: 0 },
        { user: "Ava", points: 202 },
        { user: "Noah", points: 187 },
      ],
    },
  },
};

// --------------------------
// Helpers
// --------------------------
const LS_KEY = "fantasy-speed-skating-team-v1";

function useLocalStorageState(key, initialValue) {
  const [state, setState] = useState(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : initialValue;
    } catch {
      return initialValue;
    }
  });
  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(state));
  }, [key, state]);
  return [state, setState];
}
function classNames(...xs) {
  return xs.filter(Boolean).join(" ");
}
function initials(name) {
  return name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase();
}
function currencyM(m) {
  return `€${m.toFixed(1)}M`;
}
function computeSeasonPoints(starterIds) {
  return MOCK_DATA.events.reduce((sum, ev) => {
    const pts = starterIds.reduce((acc, id) => acc + (ev.results[id] || 0), 0);
    return sum + pts;
  }, 0);
}

// --------------------------
// Small UI bits (neon / glass)
// --------------------------
function SlotCircle({ filled, label, onClick, photo }) {
  return (
    <button
      onClick={onClick}
      className={classNames(
        "w-16 h-16 rounded-full overflow-hidden flex items-center justify-center text-xs font-semibold border transition transform active:scale-[0.98]",
        filled
          ? "border-cyan-400 shadow-[0_0_0_2px_rgba(34,211,238,0.35)]"
          : "border-white/20 text-slate-300 bg-white/5"
      )}
    >
      {photo ? (
        <img src={photo} alt={label} className="object-cover w-full h-full" />
      ) : (
        <span className="text-slate-100">{label}</span>
      )}
    </button>
  );
}
function Tag({ children }) {
  return (
    <span className="px-2 py-0.5 rounded-full bg-white/10 text-slate-100 text-[11px] border border-white/15">
      {children}
    </span>
  );
}
function Stat({ label, value }) {
  return (
    <div className="flex flex-col">
      <span className="text-[11px] text-slate-300">{label}</span>
      <span className="text-base font-semibold text-white">{value}</span>
    </div>
  );
}
function Card({ children, className = "" }) {
  return (
    <section className={classNames("p-4 rounded-2xl border border-white/10 bg-white/5 backdrop-blur", className)}>
      {children}
    </section>
  );
}

// --------------------------
// Header (bigger, dynamic)
// --------------------------
function Header({ route, myPoints }) {
  const titleMap = {
    home: "HOME",
    team: "MY TEAM",
    events: "EVENTS",
    leaderboards: "LEADERBOARDS",
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50">
      <div className="bg-gradient-to-r from-[#0a1a2f] to-[#000814] border-b border-white/10 shadow-lg">
        <div className="max-w-md mx-auto px-5 pt-5 pb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap size={22} className="text-sky-400" />
            <h1 className="font-bold text-white text-xl tracking-wide">
              {titleMap[route.id]}
            </h1>
          </div>
          <div className="hidden xs:block text-right">
            <div className="text-[11px] uppercase text-slate-300">Season Pts</div>
            <div className="text-white font-semibold">{myPoints}</div>
          </div>
        </div>

        {/* Team header chip (only on Team) */}
        {route.id === "team" && (
          <div className="max-w-md mx-auto px-5 pb-4">
            <div className="w-full bg-gradient-to-r from-sky-600/20 to-blue-500/10 p-3 rounded-xl border border-white/10">
              <div className="uppercase text-[11px] text-sky-300 tracking-wider mb-1">
                Blade The Runners
              </div>
              <div className="text-lg font-bold text-white">{myPoints} pts</div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}

// --------------------------
// Home
// --------------------------
function Home() {
  const upcoming = MOCK_DATA.events[0];
  return (
    <div className="max-w-md mx-auto p-3 space-y-3">
      <Card>
        <h2 className="text-lg font-semibold text-white mb-1">Season</h2>
        <p className="text-xs text-slate-300">
          ISU Short Track World Tour — 500m Fantasy. Cumulative points across all events.
        </p>
        <div className="mt-4 grid grid-cols-3 gap-3">
          <Stat label="Events" value={MOCK_DATA.events.length} />
          <Stat label="Top Price Tier" value="€35–50M" />
          <Stat label="Budget" value="€100M" />
        </div>
      </Card>

      <Card>
        <div className="flex items-center justify-between mb-2">
          <div className="text-white font-semibold">{upcoming.name}</div>
          <Tag>Next Event</Tag>
        </div>
        <div className="text-xs text-slate-300">
          {upcoming.city}, {upcoming.country} — {upcoming.date}
        </div>
      </Card>

      <Card>
        <h3 className="text-white font-semibold mb-2 text-sm">Price Tiers</h3>
        <div className="grid grid-cols-2 gap-2 text-xs">
          {[
            ["Top 10", "€35–50M"],
            ["Top 20", "€25–35M"],
            ["Top 50", "€18–25M"],
            ["Top 100", "€10–18M"],
            ["Emerging", "€5–10M"],
          ].map(([t, v]) => (
            <div key={t} className="p-3 rounded-xl bg-white/5 border border-white/10 text-slate-200">
              <div className="font-medium">{t}</div>
              <div className="text-slate-300">{v}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// --------------------------
// Team (builder)
// --------------------------
function Team({ openProfile }) {
  const [team, setTeam] = useLocalStorageState(LS_KEY, {
    name: "You",
    budgetM: 100,
    squad: [],
    starters: [],
  });

  const athletes = MOCK_DATA.athletes;

  const spent = useMemo(() => {
    return team.squad.reduce((sum, id) => {
      const a = athletes.find((x) => x.id === id);
      return sum + (a?.priceM || 0);
    }, 0);
  }, [team.squad, athletes]);

  const remaining = (team.budgetM - spent).toFixed(1);

  function addToSquad(id) {
    if (team.squad.includes(id)) return;
    const a = athletes.find((x) => x.id === id);
    if (!a) return;
    const newSpent = spent + a.priceM;
    if (newSpent > team.budgetM) return alert("Budget exceeded");
    if (team.squad.length >= 5) return alert("Squad limit reached (5)");
    setTeam({ ...team, squad: [...team.squad, id] });
  }
  function removeFromSquad(id) {
    setTeam({
      ...team,
      squad: team.squad.filter((x) => x !== id),
      starters: team.starters.filter((x) => x !== id),
    });
  }
  function toggleStarter(id) {
    if (!team.squad.includes(id)) return;
    const isStarter = team.starters.includes(id);
    if (isStarter) setTeam({ ...team, starters: team.starters.filter((x) => x !== id) });
    else {
      if (team.starters.length >= 3) return alert("Only 3 starters can be active");
      setTeam({ ...team, starters: [...team.starters, id] });
    }
  }

  const seasonPoints = useMemo(() => computeSeasonPoints(team.starters), [team.starters]);

  return (
    <div className="max-w-md mx-auto p-3 space-y-3">
      <Card className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-white font-semibold">Build Your Squad</h2>
          <div className="flex items-center gap-3">
            <Stat label="Spent" value={currencyM(spent)} />
            <Stat label="Left" value={currencyM(Number(remaining))} />
          </div>
        </div>

        {/* Starters */}
        <div>
          <div className="text-xs text-slate-300 mb-2">Active Lineup — 3 starters score</div>
          <div className="flex items-center gap-3">
            {[0, 1, 2].map((i) => {
              const id = team.starters[i];
              const a = athletes.find((x) => x.id === id);
              return (
                <SlotCircle
                  key={i}
                  filled={Boolean(a)}
                  label={a ? initials(a.name) : "+"}
                  photo={a?.photo}
                  onClick={() => a && toggleStarter(a.id)}
                />
              );
            })}
          </div>
        </div>

        {/* Reserves */}
        <div>
          <div className="text-xs text-slate-300 mb-2">Reserves — 2 backup skaters</div>
          <div className="flex items-center gap-3">
            {Array.from({ length: 2 }).map((_, i) => {
              const reserves = team.squad.filter((x) => !team.starters.includes(x));
              const id = reserves[i];
              const a = athletes.find((x) => x.id === id);
              return (
               <SlotCircle
                  key={i}
                  filled={Boolean(a)}
                  label={a ? initials(a.name) : "+"}
                  photo={a?.photo}
                  onClick={() => a && toggleStarter(a.id)}
                />
              );
            })}
          </div>
        </div>
      </Card>

      {/* Squad list */}
      <Card className="space-y-2">
        <div className="text-white font-semibold mb-1 text-sm">Your Selection</div>
        <div className="grid gap-2">
          {team.squad.map((id) => {
            const a = athletes.find((x) => x.id === id);
            if (!a) return null;
            const isStarter = team.starters.includes(id);
            return (
              <div key={id} className={classNames(
                "p-3 rounded-xl border flex items-center justify-between",
                isStarter ? "border-cyan-400/60 bg-cyan-500/10" : "border-white/10 bg-white/5"
              )}>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full overflow-hidden border border-white/15 bg-white/10 flex items-center justify-center">
                    {a.photo ? (
                      <img src={a.photo} alt={a.name} className="object-cover w-full h-full" />
                    ) : (
                      <span className="text-slate-100 font-semibold text-sm">{initials(a.name)}</span>
                    )}
                  </div>
                  <div>
                    <div className="text-slate-100 font-medium cursor-pointer hover:underline" onClick={() => openProfile(a.id)}>
                      {a.name} <span className="text-slate-300">({a.country})</span>
                    </div>
                    <div className="text-[11px] text-slate-400">Rank #{a.worldRank} • Form {a.form}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Tag>{currencyM(a.priceM)}</Tag>
                  <button
                    onClick={() => toggleStarter(id)}
                    className={classNames(
                      "px-2 py-1 rounded-lg text-[12px] border",
                      isStarter ? "bg-cyan-500 text-black border-cyan-400" : "bg-white/10 text-slate-100 border-white/15"
                    )}
                  >
                    {isStarter ? "Starter" : "Bench"}
                  </button>
                  <button onClick={() => removeFromSquad(id)} className="px-2 py-1 rounded-lg text-[12px] bg-white/10 text-slate-100 border border-white/15">
                    Remove
                  </button>
                </div>
              </div>
            );
          })}
          {team.squad.length === 0 && <div className="text-xs text-slate-400">No skaters selected yet.</div>}
        </div>
      </Card>

      {/* Transfer Market */}
      <Card className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="text-white font-semibold text-sm">Transfer Market</div>
          <Tag>{currencyM(Number(remaining))} left</Tag>
        </div>
        <div className="flex flex-wrap gap-1 text-[11px]">
          <Tag>Top 10 €35–50M</Tag>
          <Tag>Top 20 €25–35M</Tag>
          <Tag>Top 50 €18–25M</Tag>
          <Tag>Top 100 €10–18M</Tag>
          <Tag>Emerging €5–10M</Tag>
        </div>
        <div className="space-y-2 max-h-[52vh] overflow-auto pr-1">
          {athletes.slice().sort((a, b) => a.worldRank - b.worldRank).map((a) => {
            const inSquad = team.squad.includes(a.id);
            const canAfford = spent + a.priceM <= team.budgetM;
            return (
              <div key={a.id} className="p-3 rounded-xl border border-white/10 bg-white/5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full overflow-hidden border border-white/15 bg-white/10 flex items-center justify-center">
                    {a.photo ? (
                      <img src={a.photo} alt={a.name} className="object-cover w-full h-full" />
                    ) : (
                      <span className="text-slate-100 font-semibold text-sm">{initials(a.name)}</span>
                    )}
                  </div>
                  <div>
                    <div className="text-slate-100 font-medium cursor-pointer hover:underline" onClick={() => openProfile(a.id)}>
                      {a.name} <span className="text-slate-300">({a.country})</span>
                    </div>
                    <div className="text-[11px] text-slate-400">Rank #{a.worldRank} • Form {a.form}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Tag>{currencyM(a.priceM)}</Tag>
                  {inSquad ? (
                    <button onClick={() => removeFromSquad(a.id)} className="px-2 py-1 rounded-lg text-[12px] bg-white/10 text-slate-100 border border-white/15">
                      Remove
                    </button>
                  ) : (
                    <button
                      onClick={() => addToSquad(a.id)}
                      disabled={!canAfford || team.squad.length >= 5}
                      className={classNames(
                        "px-2 py-1 rounded-lg text-[12px] border",
                        canAfford && team.squad.length < 5
                          ? "bg-cyan-500 text-black border-cyan-400"
                          : "bg-white/10 text-slate-400 border-white/15 cursor-not-allowed"
                      )}
                    >
                      Add
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
        <div className="mt-2 p-3 rounded-xl bg-white/5 border border-white/10 text-xs text-slate-200 flex items-center justify-between">
          <span>Projected total (current starters)</span>
          <span className="font-semibold text-white">{seasonPoints} pts</span>
        </div>
      </Card>
    </div>
  );
}

// --------------------------
// Events
// --------------------------
function Events({ starters }) {
  return (
    <div className="max-w-md mx-auto p-3 space-y-3">
      {MOCK_DATA.events.map((ev) => (
        <Card key={ev.id}>
          <div className="flex items-center justify-between mb-2">
            <div className="text-white font-semibold">{ev.name}</div>
            <Tag>Event</Tag>
          </div>
          <div className="text-[11px] text-slate-300 mb-3">
            {ev.city}, {ev.country} — {ev.date}
          </div>

          <div className="mb-3 flex items-center gap-2">
            {Array.from({ length: 3 }).map((_, i) => {
              const id = starters[i];
              const a = MOCK_DATA.athletes.find((x) => x.id === id);
              return <SlotCircle
                  key={i}
                  filled={Boolean(a)}
                  label={a ? initials(a.name) : ""}
                  photo={a?.photo}
                  onClick={() => {}}
                />
            })}
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-[12px] text-slate-200">
              <thead>
                <tr className="text-left text-slate-300">
                  <th className="py-2">Pos</th>
                  <th>Skater</th>
                  <th>Country</th>
                  <th className="text-right">Points</th>
                </tr>
              </thead>
              <tbody>
                {Object.entries(ev.results)
                  .sort(([, pA], [, pB]) => pB - pA)
                  .map(([athId, pts], idx) => {
                    const a = MOCK_DATA.athletes.find((x) => x.id === athId);
                    return (
                      <tr key={athId} className="border-t border-white/10">
                        <td className="py-2">{idx + 1}</td>
                        <td className="font-medium">{a?.name || athId}</td>
                        <td>{a?.country || ""}</td>
                        <td className="text-right font-semibold">{pts}</td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </Card>
      ))}
    </div>
  );
}

// --------------------------
// Leaderboards
// --------------------------
function Leaderboards({ myPoints }) {
  const [tab, setTab] = useState("global");
  const { global, countries, privateLeague } = MOCK_DATA.leaderboards;
  const myRow = { user: "You", points: myPoints };

  return (
    <div className="max-w-md mx-auto p-3 space-y-3">
      <div className="flex gap-2">
        {[
          { id: "global", label: "World" },
          { id: "countries", label: "Country" },
          { id: "private", label: "Private" },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={classNames(
              "px-3 py-1.5 rounded-full text-xs border transition",
              tab === t.id ? "bg-cyan-500 text-black border-cyan-400" : "bg-white/5 text-slate-100 border-white/10"
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "global" && (
        <Card>
          <div className="text-white font-semibold mb-2 text-sm">World Ranking</div>
          <Table rows={[myRow, ...global]} headers={["Rank", "User", "Points"]} rowMap={(r, i) => [i + 1, r.user, r.points]} />
        </Card>
      )}

      {tab === "countries" && (
        <Card>
          <div className="text-white font-semibold mb-2 text-sm">Country Ranking</div>
          <Table rows={countries} headers={["Rank", "User", "Country", "Points"]} rowMap={(r, i) => [i + 1, r.user, r.country, r.points]} />
        </Card>
      )}

      {tab === "private" && (
        <Card>
          <div className="flex items-center justify-between mb-2">
            <div className="text-white font-semibold text-sm">{privateLeague.name}</div>
            <Tag>Code: {privateLeague.code}</Tag>
          </div>
          <Table rows={[myRow, ...privateLeague.table.filter((x) => x.user !== "You")]} headers={["Rank", "User", "Points"]} rowMap={(r, i) => [i + 1, r.user, r.points]} />
        </Card>
      )}
    </div>
  );
}
function Table({ headers, rows, rowMap }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-[12px] text-slate-200">
        <thead>
          <tr className="text-left text-slate-300">
            {headers.map((h) => (
              <th key={h} className="py-2 pr-3">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, idx) => (
            <tr key={idx} className="border-t border-white/10">
              {rowMap(r, idx).map((cell, i) => (
                <td key={i} className={classNames("py-2 pr-3", i === headers.length - 1 && "text-right font-semibold")}>{cell}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// --------------------------
// Player Profile (modal)
// --------------------------
function PlayerSheet({ id, onClose }) {
  const a = MOCK_DATA.athletes.find((x) => x.id === id);
  if (!a) return null;
  return (
  <div
    role="dialog"
    aria-modal="true"
    className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex justify-center p-3"
    onClick={onClose}
  >
    <div
      className="w-full max-w-md max-h-[90vh] overflow-y-auto my-auto rounded-2xl border border-white/10 bg-[#0b1320]/95 text-slate-100 p-9"
      onClick={(e) => e.stopPropagation()}
    >
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full overflow-hidden border border-white/15 bg-white/10 flex items-center justify-center">
            {a.photo ? (
              <img src={a.photo} alt={a.name} className="object-cover w-full h-full" />
            ) : (
              <span className="text-slate-100 font-bold">{initials(a.name)}</span>
            )}
          </div>
          <div>
            <div className="text-base font-semibold">
              {a.name} <span className="text-slate-300">({a.country})</span>
            </div>
            <div className="text-[11px] text-slate-400">
              World Rank #{a.worldRank} • Form {a.form}
            </div>
          </div>
        </div>
        <button
          onClick={onClose}
          className="px-3 py-1.5 rounded-lg text-[12px] bg-white/10 border border-white/15"
        >
          Close
        </button>
      </div>

      <div className="grid grid-cols-3 gap-3 mb-5">
        <div className="p-3 rounded-xl bg-white/5 border border-white/10">
          <div className="text-[11px] text-slate-300">Price</div>
          <div className="font-semibold text-white">{currencyM(a.priceM)}</div>
        </div>
        <div className="p-3 rounded-xl bg-white/5 border border-white/10">
          <div className="text-[11px] text-slate-300">Season Points</div>
          <div className="font-semibold text-white">
            {MOCK_DATA.events.reduce((sum, ev) => sum + (ev.results[a.id] || 0), 0)} pts
          </div>
        </div>
        <div className="p-3 rounded-xl bg-white/5 border border-white/10">
          <div className="text-[11px] text-slate-300">Price Trend</div>
          <div className="font-semibold text-white">{a.priceHistory.join(" → ")}</div>
        </div>
      </div>

      {(a.privateInfo || a.sportiveInfo) && (
        <div className="space-y-4 text-sm leading-relaxed">
          {a.sportiveInfo && (
            <div>
              <div className="text-[11px] uppercase text-sky-300 tracking-wide mb-1">Sportive</div>
              <p className="text-slate-200 text-justify">{a.sportiveInfo}</p>
            </div>
          )}
          {a.privateInfo && (
            <div>
              <div className="text-[11px] uppercase text-sky-300 tracking-wide mb-1">Private</div>
              <p className="text-slate-200 text-justify">{a.privateInfo}</p>
            </div>
          )}
        </div>
      )}
    </div>
  </div>
);

}

// --------------------------
// Bottom Navigation (mobile)
// --------------------------
function BottomNav({ route, setRoute }) {
  const items = [
    { id: "home", label: "Home", icon: HomeIcon },
    { id: "team", label: "Team", icon: Users },
    { id: "events", label: "Events", icon: Calendar },
    { id: "leaderboards", label: "Leaders", icon: Trophy },
  ];
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-[#0b1c33]/90 backdrop-blur-md border-t border-white/10">
      <div className="max-w-md mx-auto grid grid-cols-4">
        {items.map((t) => {
          const Icon = t.icon;
          const active = route.id === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setRoute({ id: t.id })}
              className="py-3 text-xs flex flex-col items-center"
            >
              <Icon size={22} className={active ? "text-sky-400" : "text-gray-400"} />
              <span className={classNames("mt-1", active ? "text-sky-300" : "text-gray-500")}>
                {t.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}

// --------------------------
// App Shell
// --------------------------
export default function App() {
  const [route, setRoute] = useState({ id: "home" });
  const [profileId, setProfileId] = useState(null);
  const [team] = useLocalStorageState(LS_KEY, { name: "You", budgetM: 100, squad: [], starters: [] });
  const myPoints = useMemo(() => computeSeasonPoints(team.starters), [team.starters]);

  // Lock body scroll when modal open
  useEffect(() => {
    const prev = document.body.style.overflow;
    if (profileId) document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = prev; };
  }, [profileId]);

  function openProfile(id) { setProfileId(id); }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#071427] via-[#0b1c33] to-black text-slate-100">
      {!profileId && <Header route={route} myPoints={myPoints} />}

      <main
        aria-hidden={Boolean(profileId)}
        className={classNames(
          "pb-20 transition-all duration-200",
          route.id === "team" ? "pt-[150px]" : "pt-[70px]"
        )}
      >
        {route.id === "home" && <Home />}
        {route.id === "team" && <Team openProfile={openProfile} />}
        {route.id === "events" && <Events starters={team.starters} />}
        {route.id === "leaderboards" && <Leaderboards myPoints={myPoints} />}
      </main>

      {profileId && <PlayerSheet id={profileId} onClose={() => setProfileId(null)} />}

      {!profileId && <BottomNav route={route} setRoute={setRoute} />}
    </div>
  );
}

